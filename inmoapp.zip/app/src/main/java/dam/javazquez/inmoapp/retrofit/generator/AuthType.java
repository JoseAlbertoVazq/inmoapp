package dam.javazquez.inmoapp.retrofit.generator;

public enum AuthType {
    NO_AUTH, BASIC, JWT
}
